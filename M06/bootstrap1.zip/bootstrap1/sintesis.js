
var randVelocidad = Math.floor((Math.random() * this.velocidad) + 1);
var sprints = [];

function Cargol() {

    this.nombre;
    this.puntos;
    this.velocidad;
    this.distancia;
    this.ranking;

    this.addAvansa = function () {
        return randVelocidad;
    };



}


var k1 = new Cargol();
k1.nombre = "Cargol 1";
k1.puntos = 0;
k1.velocidad = 10 + k1.puntos;

var c2 = new Cargol();
k2.nombre = "Cargol 2";
k2.puntos = 0;
k2.velocidad = 10 + k2.puntos;

var k3 = new Cargol();
k3.nombre = "Cargol 3";
k3.puntos = 0;
k3.velocidad = 10 + k3.puntos;

var k4 = new Cargol();
k4.nombre = "Cargol 4";
k4.puntos = 0;
k4.velocidad = 10 + k4.puntos;


function inici() {


    for (i = 0; posiciones.length; i++) {
        var datos = posiciones[i];

        datos.nombre;
        datos.velocidad;
    }

}
var posicions = [k1, k2, k3, k4];


function ranking() {
    for (k = 0; k < posiciones.length; k++) {
        //arreglar mostrar
        info.innerHTML += "<a>posicion</a>" + k + "<div>" + posiciones.name + "</div>" + "<a>velocitat</a>" + posiciones;
    }
    //test
    posiciones[0];
    posiciones[1];
    posiciones[2];
    posiciones[3];
    posiciones[4];

}
function mostraArray() {
    var info = document.getElementById("infoArray");
    for (k = 0; k < posicions.length; k++) {
        info.innerHTML += "<div>" + posicions[k] + "</div>";
    }

    function finalizaCarrera() {

    }

    function run() {

    }

    function borrar() {
        // hacer lo mismo pero con la carrera !

        var posiciones = [0, 0, 0, 0];
    }

    function nuevaCarrera() {
        var numero = window.prompt("Indica el numero");

        array.splice(numero, 1);

    }

    function sprints() {
        for (i = 0; sprint.length; i++) {
            var sprints = sprint[i];

            //sprints.
        }
    }
}